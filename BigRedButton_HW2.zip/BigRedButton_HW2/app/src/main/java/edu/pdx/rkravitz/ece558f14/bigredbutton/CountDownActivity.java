/**
 * @author Roy Kravitz (roy.kravitz@pdx.edu)
 * 
 * This class implements the count down functionality of the
 * BigRedButton app.  It makes use of Android's CountDownTimer()
 * class and Java's SimpleDateFormat() class. <BR>
 * 
 * The CountDownTImer() class does just what the name says...
 * It takes a starting time (in milliseconds) and counts down
 * to 0 with periodic calls to its onTick() method.  The CountDownTimer
 * is implemented as an inner class per the Android documentation
 */
package edu.pdx.rkravitz.ece558f14.bigredbutton;

import java.text.SimpleDateFormat;
import java.util.Locale;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


public class CountDownActivity extends Activity {
	public static final String TAG = "CountDownActivity";
	public static final long REPORT_COUNT_INTERVAL = 1000;
	public static final String EXTRA_TIMELEFT = "ece.pdx.rkravitz.ece558f14.time_left";
	private MyCountDownTimer mCountdown;
	private TextView mTimeLeftText;
	private ImageButton mBigRedButton;
	
	private long mTimeLeft, mStartTime;
	private boolean mCountDownHasStarted = false;

	public static Intent newIntent(Context packageContext, long number){
		Intent i = new Intent(packageContext, CountDownActivity.class);
		i.putExtra(EXTRA_TIMELEFT, number);
		return i;
	}


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_countdown);
			
		// initialize the countdown timer.  It was passed to this activity from SetTimeActivity() as a long
		// We will implement the countdown timer as an inner class called MyCountDownTimer()
		mStartTime = getIntent().getLongExtra(SetTimeActivity.EXTRA_TIMELEFT, 0);
		mCountdown = new MyCountDownTimer(mStartTime, REPORT_COUNT_INTERVAL);
		
		// initialize the Countdown Text
		mTimeLeftText = (TextView) findViewById(R.id.TimeLeftText);
		mTimeLeftText.setText(mCountdown.formatCount(0L));
		
		// start the countdown
		mCountdown.start();
		mCountDownHasStarted = true;
		
		// initialize the Big Red Button and set its listener
		mBigRedButton = (ImageButton) findViewById(R.id.BigRedBtn);
		mBigRedButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (!mCountDownHasStarted) {
					if (mTimeLeft <= 0) {
						mTimeLeft = mStartTime;
					}
					
					if (mCountdown == null) {
						mCountdown = new MyCountDownTimer(mTimeLeft, REPORT_COUNT_INTERVAL);
					}
					mTimeLeftText.setText(mCountdown.formatCount(mTimeLeft));
					mCountdown.start();
					mCountDownHasStarted = true;
					
				}
				else {
					mCountdown.cancel();
					mCountdown = null;	
					mCountDownHasStarted = false;
					if (mTimeLeft > 0L) {
						Toast.makeText(getBaseContext(), R.string.CountdownStoppedText, Toast.LENGTH_LONG).show();
					}
					else {
						Toast.makeText(getBaseContext(), R.string.CountdownNiceTryText, Toast.LENGTH_LONG).show();	
					}
				}
			
			}
		});
	}
		
		
		
	public class MyCountDownTimer extends CountDownTimer {
		private final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("mm:ss", Locale.US);

		public MyCountDownTimer(long startTime, long interval) {
			super(startTime, interval);
		}
		
		@Override
		public void onFinish() {
			mTimeLeft = 0L;
			mTimeLeftText.setText(formatCount(mTimeLeft));
			Toast.makeText(getBaseContext(), R.string.CountdownExpiredText, Toast.LENGTH_LONG).show();
		}
		
		@Override
		public void onTick(long millisUntilFinished) {
			mTimeLeft = millisUntilFinished;
			mTimeLeftText.setText(formatCount(mTimeLeft));		
		}
		
		public String formatCount(long count) {
			return DATE_FORMAT.format(count);
		}		
	}

}