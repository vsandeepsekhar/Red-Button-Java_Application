/**
 * @author Roy Kravitz (roy.kravitz@pdx.edu)
 * 
 * This interface is used to pass the count down time from
 * the TimePicker() back to the host activity (SetTimeActivity).
 */
package edu.pdx.rkravitz.ece558f14.bigredbutton;

public interface OnCountdownStartedListener {
	public abstract void onCountDownStarted(long timeleft_millis);

}
