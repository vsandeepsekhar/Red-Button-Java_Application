/**
 * @author Roy Kravitz (roy.kravitz@pdx.edu)
 * 
 * This class contains a fragment hosted by SetTimeActivity().  The fragment
 * should manage the TimePicker widget and the Start Counter image button
 * in the layout file settime_fragment.xml which has been provided.
 * 
 * @note
 * IMPORTANT:  The TimePicker widget expects hours and minutes but
 * we are going to scale the values to minutes and seconds
 */
package edu.pdx.rkravitz.ece558f14.bigredbutton;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TimePicker;

public class SetTimeFragment extends Fragment {
	private TimePicker mTP;	
	private Button mSetTimeBtn;
	private long mTimeinMillis;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View viewHierarchy = inflater.inflate(R.layout.settime_fragment, container, false);
		
		// TODO - instantiate the TimePicker and set its starting values
		// The TimePicker widget (and the TimePicker Dialog Fragment, for that matter) only implement
		// hours and minutes and we really want seconds.  So we'll cheat a little and use the hours
		// returned by the TimePicker for minutes and the minutes returned by the TimePicker for seconds.
		// Yes, this does limit the maximum countdown time to 23 minutes and 59 seconds, but a) that 
		// should be plenty of time for any self-respecting hero and b) it sure beats
		// trying to create a custom widget with the desired functionality.
		mTP = (TimePicker)viewHierarchy.findViewById(R.id.timePicker1);
        mTP.setIs24HourView(true);
        mTP.setCurrentHour(0);
        mTP.setCurrentMinute(0);

		// TODO - instantiate the "Start Countdown" button and create its OnClickListener
		// The onClick() method should get the time from the TimePicker, scale it for minutes and seconds
		// and convert to milliseconds.  Once that is done is should notify SetTimeActivity() that a count down
		// time is available by invoking onCountdownStartedListener.onCountDownStarted().
		mSetTimeBtn = (Button) viewHierarchy.findViewById(R.id.StartTimerBtn);
		mSetTimeBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//  TODO - get the time from the TimePicker, scale it for minutes and seconds
				// and convert to milliseconds
                mTimeinMillis = ((mTP.getCurrentHour()*60)*1000)+(mTP.getCurrentMinute()*1000);
				// TODO - notify activity the SetTime activity that the countdown has started
                Fragment fmt = new Fragment();
                SetTimeActivity sta = new SetTimeActivity();

                sta.onCountDownStarted(mTimeinMillis);
			}
		});
		
		return viewHierarchy;		
	}
	
	
	
	

}
