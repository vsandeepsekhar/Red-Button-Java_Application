/**
 * @author Roy Kravitz (roy.kravitz@pdx.edu)
 * 
 * This is the generic SingleFragmentActivity() class as defined and used
 * in Android Programming: The Big Nerd Ranch Guide by Bill Phillips and Brian
 * Hardy. Copyright 2013 by Big Nerd Ranch.
 */

package edu.pdx.rkravitz.ece558f14.bigredbutton;

import edu.pdx.rkravitz.ece558f14.bigredbutton.R;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

public abstract class SingleFragmentActivity extends FragmentActivity {
	
	/**
	 * abstract method to create a fragment of the desired class
	 * 
	 * @return Fragment reference to the fragment to be added to the activity
	 */
	protected abstract Fragment createFragment();
	
	/**
	 * onCreate() method for a generic single fragment activity
	 * 
	 * @param Bundle used to preserve and pass data to/from the fragment
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fragment);
		android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
		Fragment fragment = fm.findFragmentById(R.id.fragmentContainer);
		
		if (fragment == null) {
			fragment = createFragment();
			fm.beginTransaction()
				.add(R.id.fragmentContainer, fragment)
				.commit();
		}
	}

}
