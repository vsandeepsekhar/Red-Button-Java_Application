/**
 * @author Roy Kravitz (roy.kravitz@pdx.edu)
 * 
 * This is the Alert dialog used to give the evil scientist
 * one last chance to choose between unleashing his heinous event
 * or saving it for another day.  The code for this class is based on the
 * the Android documentation guide on Dialogs ( http://developer.android.com/guide/topics/ui/dialogs.html ) <BR><BR>
 * 
 * The bulk of the work, however, is left to you to complete.  Let it suffice to say that this fragment is hosted
 * by SetTimeActivity() which should implement the UnleashCatastropheDialogListener() methods.
 * 
 */
package edu.pdx.rkravitz.ece558f14.bigredbutton;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

/**
 * @author rkravitz
 *
 */
public class UnleashCatastropheDialogFragment extends DialogFragment {
	public static final String TAG = "UnleashCatastropheFragment";
	
	UnleashCatastropheDialogListener mListener;
	
	public interface UnleashCatastropheDialogListener {
		public void onDialogPositiveClick(DialogFragment dialog);
		public void onDialogNegativeClick(DialogFragment dialog);
	}
	
	@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
		// TODO - Build the dialog with two buttons (an EXECUTE) button
		// and a Cancel button.  The onClick() methods for those buttons
		// should invoke the matching callback methods for the
		// UnleashCatastrophicDialogListner() interface.
		
        // Use the Builder class for convenient dialog construction
		// You may implement the onClick() listeners for the dialog buttons here
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.dialog_areyousure);
        builder.setMessage(R.string.dialog_lastchance);
        final AlertDialog.Builder mBuilder1 = builder.setPositiveButton(R.string.dialog_execute, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mListener.onDialogPositiveClick((DialogFragment) dialog);
                getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_OK, getActivity().getIntent());
            }
        });
        final AlertDialog.Builder mBuilder2 = builder.setNegativeButton(R.string.dialog_cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mListener.onDialogNegativeClick((DialogFragment) dialog);
                getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_CANCELED, getActivity().getIntent());
            }
        });

        // Create the AlertDialog object and return it
        return builder.create();
    }
	
	// Override the Fragment.onAttach() method to instantiate the UpdateCatastropheDialogListener
	// This code is taken from d.anadroid.com. H-m-m, perhaps there is a use for onAttach() after all
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the UpdateCatastropheDialogListener so we can send events to the host activity
            mListener = (UnleashCatastropheDialogListener) activity;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(activity.toString()
                    + " must implement UnleashCatastropheListener");
        }
    }
}

