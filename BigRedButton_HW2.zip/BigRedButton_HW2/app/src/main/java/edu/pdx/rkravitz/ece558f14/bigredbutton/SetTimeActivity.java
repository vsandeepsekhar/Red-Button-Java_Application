/**
 * @author Roy Kravitz (roy.kravitz@pdx.edu)
 * 
 * This class is used in the BigRedButton app to set the countdown time.
 * The class makes use of the SingleFragmentActivity() and the activity_fragment.xml
 * layout as presented, discussed, and used in BNRG Chap. 9.  As a result, this
 * class extends SingleFragmentActivity instead of FragmentActivity and needs
 * to override the createFragment() method to return an instance of itself. <BR> <BR>
 * 
 * This class assumes (and relies) on the existence of two fragments: <BR>
 * 		o SetTimeFragment() - Uses a TimePicker to set the countdown time and a button to confirm the choice
 * 		o UnleashCatastropheDialog() - An Alert dialog to give the evil scientist one last choice
 * 
 * Both of the fragments use listeners as shown during class and in the lecture packages to pass data
 * back to this host activity.  All of the listener methods must be implemented.
 */
package edu.pdx.rkravitz.ece558f14.bigredbutton;

import android.app.Activity;
//import android.app.FragmentManager;
import android.support.v4.app.FragmentManager;
import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TimePicker;
import android.widget.Toast;

public class SetTimeActivity extends SingleFragmentActivity implements OnCountdownStartedListener,
	UnleashCatastropheDialogFragment.UnleashCatastropheDialogListener {
	
	public static final String TAG = "SetTimeActivity";
	public static final String EXTRA_TIMELEFT = "ece.pdx.rkravitz.ece558f14.time_left";


	private long mTimeLeft;

	/**
	 * 
	 */
	@Override
	protected Fragment createFragment() {
		// TODO - returns an instance of SetTimeFragment
        android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fm = fragmentManager.findFragmentById(R.id.fragmentContainer);
        if(fm==null){
            fm = new SetTimeFragment();
            fragmentManager.beginTransaction()
                    .add(R.id.fragmentContainer, fm)
                    .commit();
        }
		//return null;
        return fm;
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.set_time, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		//switch(requestCode) {
			//case DIALOG_FRAGMENT:

				if (resultCode == Activity.RESULT_OK) {
					// After Ok code.
					//:ToDo Call the Methods for Count Down Activity
				}
				else if (resultCode == Activity.RESULT_CANCELED) {
					// After Cancel code.
					//:ToDo Call the Methods for Count Down Activity
				}
				else
				{

				}
				//break;
	}

	// callbacks from SetTimeFragment() Listener
	
	/**
	 * This method is invoked after the evil scientist has entered
	 * a countdown time.  The method should bring up an Alert dialog
	 * that gives the evil scientist a choice between executing his/her
	 * catastrophic plan or canceling it...for now.
	 * 
	 * @param timeLeft Countdown time before the catastrophic event happens
	 * 
	 * @note
	 * The app is written for the support library so use getSupportFragmentManager()
	 * instead of getFragmentManager().
	 * 
	 */
	@Override
	public void onCountDownStarted(long timeLeft) {
		// TODO - create and show the alert dialog
        FragmentManager fmn = getSupportFragmentManager();
        Fragment fragment = fmn.findFragmentById(R.id.fragmentContainer);
        if(fragment == null){
            fragment = new UnleashCatastropheDialogFragment();
            fmn.beginTransaction()
                    .add(R.id.fragmentContainer,fragment)
                    .commit();
        }
		mTimeLeft = timeLeft;
	}
	
	// callbacks from the Alert dialog  Listener
	
	/**
	 * This method should perform the action called for when the
	 * evil scientist decides to launch his heinous event. In this
	 * case that involves providing the countdown time to, and starting
	 * CountDownActivity()
	 * 
	 * @param dialog reference to the alert dialog fragment
	 * 
	 * @note
	 * I implemented the alert dialog using callbacks to this hosting
	 * activity.  Its up to you if you want to do the same thing; just
	 * make the necessary changes
	 */
	public void onDialogPositiveClick(DialogFragment dialog) {
		Toast.makeText(this, R.string.EvilLaughtText, Toast.LENGTH_LONG).show();
	    
		// TODO - provide the countdown time to CountDownActivity() and start
		// the activity
        Intent i = CountDownActivity.newIntent(SetTimeActivity.this,mTimeLeft);
        startActivity(i);
	}
	
	/**
	 * This method should perform the action called for when the
	 * evil scientist decides to cancel (not launch) his heinous event. 
	 * 
	 * @param dialog reference to the alert dialog fragment
	 * 
	 * @note
	 * I implemented the alert dialog using callbacks to this hosting
	 * activity.  Its up to you if you want to do the same thing; just
	 * make the necessary changes
	 */
	public void onDialogNegativeClick(DialogFragment dialog) {
		Toast.makeText(this, R.string.ThereIsGoodInYouText, Toast.LENGTH_LONG).show();
	}
	
}
